package com.wipro.ORS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineResumeSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
