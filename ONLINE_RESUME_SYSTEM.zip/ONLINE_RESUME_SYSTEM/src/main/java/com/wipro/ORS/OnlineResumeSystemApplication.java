package com.wipro.ORS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineResumeSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineResumeSystemApplication.class, args);
	}

}
